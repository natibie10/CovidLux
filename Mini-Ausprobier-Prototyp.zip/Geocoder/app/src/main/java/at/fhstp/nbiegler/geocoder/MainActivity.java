package at.fhstp.nbiegler.geocoder;

import androidx.annotation.LongDef;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 2;
    private LocationAddressResultReceiver addressResultReceiver;
    private TextView currentAddTv;
    private Location currentLocation;
    private LocationCallback locationCallback;

    String[] split1;

    Button button;

    RelativeLayout RL;

    //Initialize variable
    ArrayList<String> splitList = new ArrayList<>();
    ArrayList<String> warnList = new ArrayList<>();



    @SuppressWarnings("MissingPermission")
    private void startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new
                            String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
        else {
            LocationRequest locationRequest = new LocationRequest();
            locationRequest.setInterval(2000);
            locationRequest.setFastestInterval(1000);
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        }
    }
    @SuppressWarnings("MissingPermission")
    private void getAddress() {
        if (!Geocoder.isPresent()) {
            Toast.makeText(MainActivity.this, "Can't find current address, ",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(this, GetAddressIntentService.class);
        intent.putExtra("add_receiver", addressResultReceiver);
        intent.putExtra("add_location", currentLocation);
        startService(intent);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull
            int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            }
            else {
                Toast.makeText(this, "Location permission not granted, " + "restart the app if you want the feature", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private class LocationAddressResultReceiver extends ResultReceiver {
        LocationAddressResultReceiver(Handler handler) {
            super(handler);
        }
        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {
            if (resultCode == 0) {
                Log.d("Address", "Location null retrying");
                getAddress();
            }
            if (resultCode == 1) {
                Toast.makeText(MainActivity.this, "Address not found, ", Toast.LENGTH_SHORT).show();
            }
            String currentAdd = resultData.getString("address_result");
            showResults(currentAdd);
            getString(currentAdd);
        }
    }
    private void showResults(String currentAdd) {
        currentAddTv.setText(currentAdd);
    }
    @Override
    protected void onResume() {
        super.onResume();
        startLocationUpdates();
        clickButton(button);
    }

    @Override
    protected void onPause() {
        super.onPause();
        fusedLocationClient.removeLocationUpdates(locationCallback);

    }

    public void getString(String address){
        String[] separated = address.split("Locality:");
        separated[1] = separated[1].trim();
        split1 = separated[1].split("County:");
        split1[0] = split1[0].trim();
        Log.d("String",split1[0]);
        button.setEnabled(true);
    }

    public void clickButton(Button button){
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(split1 != null) {
                    Log.d("String2", split1[0]);
                    RL = findViewById(R.id.layout);
                    for (int i=0; i < splitList.size();i++){
                        if(split1[0].equals(splitList.get(i))){
                            if(warnList.get(i).contains("1")){
                                RL.setBackgroundColor(Color.GREEN);
                            }
                            if(warnList.get(i).contains("2")){
                                RL.setBackgroundColor(Color.YELLOW);
                            }
                            if(warnList.get(i).contains("3")){
                                RL.setBackgroundColor(Color.rgb(255, 165, 0));
                            }
                            if(warnList.get(i).contains("4")){
                                RL.setBackgroundColor(Color.RED);
                            }
                        }
                    }
                }
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.zeige_button);
        button.setEnabled(false);
        addressResultReceiver = new LocationAddressResultReceiver(new Handler());
        currentAddTv = findViewById(R.id.textView);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                currentLocation = locationResult.getLocations().get(0);
                getAddress();
            }
        };
        startLocationUpdates();

        //Initialize JSON Array
        String students_array = " {\"Warnstufen\": [\n" +
                "{\n" +
                "        \"Region\": \"Gemeinde\",\n" +
                "        \"GKZ\": \"31321\",\n" +
                "        \"Name\": \"Krumau am Kamp\",\n" +
                "        \"Warnstufe\": \"3\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"Region\": \"Gemeinde\",\n" +
                "        \"GKZ\": \"31322\",\n" +
                "        \"Name\": \"Langenlois\",\n" +
                "        \"Warnstufe\": \"3\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"Region\": \"Gemeinde\",\n" +
                "        \"GKZ\": \"31323\",\n" +
                "        \"Name\": \"Lengenfeld\",\n" +
                "        \"Warnstufe\": \"4\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"Region\": \"Gemeinde\",\n" +
                "        \"GKZ\": \"31324\",\n" +
                "        \"Name\": \"Lichtenau im Waldviertel\",\n" +
                "        \"Warnstufe\": \"3\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"Region\": \"Gemeinde\",\n" +
                "        \"GKZ\": \"31326\",\n" +
                "        \"Name\": \"Sankt Pölten\",\n" +
                "        \"Warnstufe\": \"1\"\n" +
                "      }\n" +
                "]\n" +
                " }";

        //Fetch JSON Array
        try {
            JSONObject jsonObject = new JSONObject(students_array);
            JSONArray jsonArray = jsonObject.getJSONArray("Warnstufen");
            for(int i=0; i<jsonArray.length();i++){
                JSONObject object = jsonArray.getJSONObject(i);
                String region = object.getString("Region");
                String name = object.getString("Name");
                String warnstufe = object.getString("Warnstufe");

                Log.d("String3",name);

                /*if(name.equals(split1[0])){
                    RL.setBackgroundColor(Color.BLUE);
                }*/

                splitList.add(name);
                warnList.add(warnstufe);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
